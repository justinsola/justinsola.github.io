// Shared content across all design directions.
// Pulled straight from justinsola.github.io@master so copy is 1:1 with the live site.

window.SITE_CONTENT = {
  name: "Justin Lucas Sola",
  nameShort: "Justin L. Sola",
  credential: "PhD",
  titleLine1: "Assistant Professor",
  titleLine2: "Sociology & the School of Data Science and Society",
  institution: "UNC–Chapel Hill",
  email: "jlsola@unc.edu",
  orcid: "0000-0002-0955-1031",
  orcidUrl: "https://orcid.org/0000-0002-0955-1031",
  cvUrl: "./files/Sola_CV.pdf",
  socDept: "https://sociology.unc.edu/people-page/justin-sola/",
  dataDept: "https://datascience.unc.edu/person/justin-sola/",

  research: "I research how people experience neighborhoods, the criminal justice system, gun ownership, and inequality. I use experiments, machine learning, longitudinal designs, interviews, and observations. I teach sociology, computational social science, criminology, and ethics in machine learning.",

  // Publications: preserves exact order and formatting from index.markdown.
  // Author string rendered separately so we can bold "Justin L. Sola" consistently.
  pubs: [
    {
      year: 2026,
      authors: [{ text: "Justin L. Sola", me: true }],
      title: "Neoliberalism in Law and Society.",
      venue: "Law & Society Review",
      note: "Online First",
      doi: "https://doi.org/10.1017/lsr.2026.10095",
      topics: ["law", "theory"],
    },
    {
      year: 2025,
      authors: [{ text: "Simon A. Cole" }, { text: "Justin L. Sola", me: true }],
      title: "First Impressions Matter: Mundane Obstacles to a Forensic Device for Probabilistic Reporting in Fingerprint Analysis.",
      venue: "Social Studies of Science",
      note: "Online First",
      doi: "https://doi.org/10.1177/03063127251333074",
      topics: ["forensics", "methods"],
    },
    {
      year: 2024,
      authors: [{ text: "Justin L. Sola", me: true }],
      title: "Pathways to concealed gun carrying.",
      venue: "Science Advances",
      note: "Vol 10, Issue 49 · Focus Article for Lanfear et al. 2024",
      noteLink: "https://doi.org/10.1126/sciadv.adp8915",
      doi: "https://doi.org/10.1126/sciadv.adu1262",
      topics: ["guns"],
      invited: true,
    },
    {
      year: 2024,
      authors: [{ text: "Justin L. Sola", me: true }, { text: "Tara D. Warner" }],
      title: "Firearms, Families, and Financial Distress: Economic Instability and Increased Gun Desire.",
      venue: "Social Science Quarterly",
      note: "Online First",
      doi: "https://doi.org/10.1111/ssqu.13462",
      topics: ["guns", "inequality"],
    },
    {
      year: 2024,
      authors: [{ text: "Justin T. Pickett" }, { text: "Justin L. Sola", me: true }, { text: "Shawn D. Bushway" }],
      title: "Partisan Differences in Hiring and Social Discrimination against Nonbinary Americans.",
      venue: "Socius",
      note: "Volume 10: 1–5",
      doi: "https://doi.org/10.1177/23780231241280014",
      topics: ["inequality", "experiments"],
    },
    {
      year: 2024,
      authors: [{ text: "Justin L. Sola", me: true }, { text: "Justin T. Pickett" }],
      title: "Widespread, bipartisan aversion exists to neighbors owning AR-15s or storing guns insecurely.",
      venue: "Proceedings of the National Academy of Sciences",
      note: "121 (16) e2311825121",
      doi: "https://doi.org/10.1073/pnas.2311825121",
      topics: ["guns", "neighborhoods"],
    },
    {
      year: 2023,
      authors: [{ text: "Justin L. Sola", me: true }, { text: "Charis E. Kubrin" }],
      title: "Making the Call: How Does Perceived Race Affect Desire to Call the Police?",
      venue: "Experimental Criminology",
      note: "Online First",
      award: "2023 American Society of Criminology Experimental Division Student Paper Award",
      doi: "https://doi.org/10.1007/s11292-023-09571-z",
      topics: ["neighborhoods", "experiments", "criminal-justice"],
    },
    {
      year: 2022,
      authors: [{ text: "Sykes et al." }, { text: "Sola", me: true }],
      title: "Barred: Labor Market Dynamics and Human Capital Development Among People on Probation and Parole.",
      venue: "Annals of the American Academy of Political and Social Science",
      note: "Volume 701 Issue 1: 28–45",
      doi: "https://doi.org/10.1177/00027162221099291",
      topics: ["criminal-justice", "inequality"],
    },
    {
      year: 2022,
      authors: [{ text: "Sykes et al." }, { text: "Sola", me: true }],
      title: "Robbing Peter to Pay Paul: Public Assistance, Monetary Sanctions, and Financial Double-Dealing in America.",
      venue: "RSF: The Russell Sage Foundation Journal of the Social Sciences",
      note: "Volume 8 Issue 1: 148–178",
      doi: "https://doi.org/10.7758/RSF.2022.8.1.07",
      topics: ["criminal-justice", "inequality"],
    },
    {
      year: 2021,
      authors: [{ text: "Justin L. Sola", me: true }],
      title: "Transmitting Desire: An Experiment on a Novel Measure of Gun Desirability in a Pandemic.",
      venue: "Sociological Perspectives",
      note: "Volume 65 Issue 5: 939–969",
      doi: "https://doi.org/10.1177/07311214211007179",
      topics: ["guns", "methods"],
    },
  ],

  nav: [
    { label: "Research", href: "./", current: true },
    { label: "About", href: "./about_me" },
    { label: "Gun desirability", href: "./gun_desirability" },
    { label: "CV", href: "./files/Sola_CV.pdf" },
    { label: "ORCID", href: "https://orcid.org/0000-0002-0955-1031" },
    { label: "Email", href: "mailto:jlsola@unc.edu" },
  ],
};

// Author rendering helper — bolds the "me" entry.
window.renderAuthors = function(authors) {
  return authors.map((a, i) => {
    const sep = i === authors.length - 1 ? "" : (authors.length === 2 ? " and " : (i === authors.length - 2 ? ", and " : ", "));
    return (a.me ? `<strong>${a.text}</strong>` : a.text) + sep;
  }).join("");
};
