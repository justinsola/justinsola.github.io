# Editing jlsola.com — quick reference

Everything on the site is hand-editable HTML. No build step, no framework — open in a text editor, save, commit.

## File layout

```
site/
├── index.html            Research / publications list
├── about.html            About me
├── gun_desirability.html Methods page
├── site.css              Shared styles (all three pages)
├── favicon.svg           Icon (editable)
├── favicon-32.png        ← link tag
├── favicon-180.png       ← apple-touch-icon
└── files/                Put CV, headshot, prompt images here
    ├── Sola_CV.pdf
    ├── edited_headshot_w1064.jpg
    ├── pistol.png / ar-15.png / hunting_rifle.png
    └── hunting_rifle_example.png
```

## Adding a publication

Open `site/index.html`. Scroll to `<ol class="pubs">`. Each publication is an `<li>` — copy the most recent one and edit in place. Structure:

```html
<li>  <!-- add class="invited" for commentaries -->
  <div class="year">2026</div>

  <div class="pub-venue">
    <span class="venue-name">Law &amp; Society Review</span>
    Online First
  </div>

  <div>
    <div class="pub-title">
      <a class="ext" href="https://doi.org/...">"Title of the paper."</a>
    </div>
    <div class="pub-authors">
      <strong>Justin L. Sola</strong>
    </div>

    <!-- optional award pill -->
    <span class="award">2024 Best Paper Award</span>
  </div>
</li>
```

Tips:
- **Year** goes in `.year`.
- **Venue** italicized name + issue info under it.
- **Authors**: wrap your name in `<strong>...</strong>`. For multiple authors, write `First A., Second B., and Third C.` — commas, Oxford comma before `and`.
- **Invited / commentary pieces**: add `class="invited"` to the `<li>` — the whole row is auto-subdued and an "Invited" tag appears.
- **External / DOI links**: always use `class="ext"` — gives them purple hover, the only place purple appears in body text.
- **Award**: drop a `<span class="award">` after the authors block for an outlined gold star pill.

## Adding a fellowship / award (About page)

`about.html`, in the `<ul class="fellowship-list">`. One `<li>` per fellowship. Add `class="flagship"` to one to highlight it with a gold border.

## Changing navigation

Every page has the same `<header class="topline">` block. To add a page to the nav, copy an `<a>` inside `<nav class="primary">` on all three pages (same markup, mark the current page with `class="current"`).

## Changing the masthead / sigil

The gold dot before "Justin L. Sola" in the top bar comes from `.topline .mark::before` in `site.css`. Change the `background` there to retint it. Change the size via `width`/`height`.

## Dropping the favicon

All three pages load:
```html
<link rel="icon" type="image/svg+xml" href="./favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="./favicon-32.png">
<link rel="apple-touch-icon" sizes="180x180" href="./favicon-180.png">
```

To redesign, edit `favicon.svg` directly (plain XML). Then export PNGs at 32 and 180 — any tool will do.

## Colors (site.css `:root`)

| Token        | Value     | Where it appears                                        |
|--------------|-----------|---------------------------------------------------------|
| `--navy`     | `#1B3D6D` | Top bar, headings, year, links, section rules           |
| `--gold`     | `#EE9900` | Link hover, current-nav, award pill, code rail, sigil   |
| `--purple`   | `#5A007E` | External-link hover, focus ring, Email/ORCID chip       |
| `--muted`    | `#5f6b7c` | Secondary text, captions, venue lines                   |
| `--ink`      | `#1c1c1c` | Body text                                               |

## Local preview

Any static server works. Fastest: from the `site/` folder run `python3 -m http.server 8000` and open `http://localhost:8000`.

## Publishing (GitHub Pages)

This lives on `justinsola.github.io`. Commit the `site/` contents to the repo root (or wherever your Jekyll workflow expects them), push, wait ~60s.
